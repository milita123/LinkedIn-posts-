# ScrapyPackage

This package contains another way to do *web scraping* on LinkedIn. Unfortunately this approach is not working anymore on LinkedIn
anymore because bot are forbidden. So,  the only way to do it is trough Selenium.